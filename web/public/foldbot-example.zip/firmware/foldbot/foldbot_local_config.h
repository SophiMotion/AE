#pragma once
// Configure a private 8-63 character Wi-Fi AP password locally.
// Add #define FOLDBOT_AP_PASSWORD "YOUR_LOCAL_VALUE" above this guard.
// Do not publish the configured file. No original password is included.
#ifndef FOLDBOT_AP_PASSWORD
#error "Set FOLDBOT_AP_PASSWORD locally before building this template"
#define FOLDBOT_AP_PASSWORD ""
#endif
static_assert(sizeof(FOLDBOT_AP_PASSWORD) >= 9 && sizeof(FOLDBOT_AP_PASSWORD) <= 64,
              "AP password must be 8-63 characters");

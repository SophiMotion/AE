from setuptools import setup

setup(
    name="foldbot_demo", version="0.0.1",
    packages=["foldbot_demo"],
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/foldbot_demo"]),
        ("share/foldbot_demo", ["package.xml"]),
    ],
    install_requires=["setuptools"], zip_safe=True,
    maintainer="Local user", maintainer_email="local@example.invalid",
    description="Untested log-only FoldBot demonstration", license="UNLICENSED",
    entry_points={"console_scripts": ["demo = foldbot_demo.demo:main"]},
)

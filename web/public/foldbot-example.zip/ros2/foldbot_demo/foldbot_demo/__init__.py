"""Untested generated FoldBot demo; no hardware acceptance."""

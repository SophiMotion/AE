# FoldBot generated source snapshot

Project ID: `foldbot-reference-20261012` · PRD revision: `1`

这是基于既有整机工程的模板复用。完整需求见 `prd.json`；配置见
`config/foldbot_config.json`；文件用途与校验见 `manifest.json`。
旧版本生成记录不会变成新需求的证据。修改需求、档位或时长后必须重新核对并生成。

## 生成证据

本次仅生成源文件与配置。未编译、未安装或运行 ROS、未烧录、未连接硬件、
未验证实物动作。没有包含历史 .bin 文件。协议 ACK、缓存反馈、步进脉冲计数
和实际到位是不同证据；舵机 raw 单位不能当作角度。

## 固件来源与本地复现

`firmware/foldbot/foldbot.ino` 与 `web_ui.h` 复用现有 Sophicar 整机源码，
保留网页、底盘、双折叠板和机械臂。原始/脱敏 SHA-256 在 `provenance.json`。
AP 口令常量改为本地配置宏，同时隐藏串口口令输出。原始工程未改动。

1. 阅读来源、需求与待确认项。用 Arduino IDE 打开 `firmware/foldbot/foldbot.ino`。
2. 在 `foldbot_local_config.h` 的保护条件之前加入本地
   `#define FOLDBOT_AP_PASSWORD "本地设置的8至63字符口令"`。未设置会故意停止编译；
   配置后文件含私人口令，不适合公开分享。
3. 源码历史设置为 ESP32S3 Dev Module、Flash 16MB、PSRAM Disabled、USB CDC
   On Boot Enabled、串口 115200；它们是来源记录，不能替代现场板卡确认。
   该源码使用 ESP32 GPTimer、cJSON、WiFi 与 ESP-IDF 接口。此生成包没有锁定并验证
   Arduino-ESP32/ESP-IDF 工具链版本，需要在真实板卡与工具链确定后单独编译验收。
4. 本轮生成未进行构建或烧录。实际上传须在硬件核对及另行明确操作后进行，
   不应自动擦除 NVS。JSON 档位和时长仅约束 AE 本机控制，不会改写固件内置参数。

## ROS 2 演示

`ros2/foldbot_demo` 是未运行、未构建的 ament_python 演示包。
默认从该目录运行 `python -m foldbot_demo.demo` 只打印一条标为离线示例的 JSON，
不导入 rclpy、不创建网络连接、不发送运动指令。生成服务没有执行这条命令。
如果之后在独立确认的 ROS 2 环境构建并安装该包，`ros2 run foldbot_demo demo`
仍默认离线退出；显式添加 `--run-ros` 才创建只记录日志的 ROS 节点，
此模式可能产生 ROS DDS 发现流量，但没有机器人传输或运动发布器。
这不能证明 ROS 已控制实机。ROS 发行版、依赖版本与实机集成均待确认。

## 必须现场确认的事项

- 磁盘来源 build 为 `foldbot-20260929-sophicar-external-driver-no-limits`；
  板上 `firmwareBuild`、限位、双轴数量、故障、急停、行程与参考点须读取实时状态。
- Sophicar ESP32-S3-N16R8 的 GPIO35–37 与八线存储器保留脚存在兼容性疑点；
  此包不声明引脚、电源、外部驱动和实际接线兼容，不提供猜测的接线替换。
- 禁限位源码不能使用限位自动归零流程。两板人工端位确认必须与真实端位一致；
  不凭软件计数推断实际位置，不继承旧控制器未经核实的 NVS 标定。
- 本机连接会初始化底盘功率档。当前选择档位 10、
  单次时长 200 ms；硬上限为档位 20、2000 ms。
  机械臂单次上限 8 raw；动作组尚未适配，不提供标定上限覆盖。
- 网页与 ROS 不同时控制 ESP32。单操作者、短租约、主动使能、离开页面撤销及
  全停属于本机控制层；此源码生成记录本身不证明任何这些功能已在硬件验收。
